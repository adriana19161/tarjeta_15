INVITACION PARA IPHONE - CODIGO FUENTE
=======================================

Esta app contiene una sola invitacion personalizada y todos sus recursos
locales. No contiene tarjetas de otros invitados. No necesita Internet para
mostrar el diseno, las imagenes, las animaciones ni la musica.

REQUISITOS Y APERTURA
---------------------

- Se necesita un Mac con Xcode 15 o posterior para compilar la app.
- La app se configura para iOS/iPadOS 16 o posterior.
- Abre el archivo Invitacion43MiguelAngelEspinosaAngelaPalma.xcodeproj en Xcode.
- Conecta el iPhone/iPad y selecciona el dispositivo como destino.
- En Signing & Capabilities, selecciona un equipo de desarrollo tuyo.
- Pulsa Run. Xcode firma e instala la app para pruebas en tu dispositivo.

Este ZIP contiene codigo fuente; no es una app ya compilada ni firmada. Para
instalarla en los iPhone de los invitados se requiere distribuir una app iOS
firmada mediante un metodo autorizado por Apple (por ejemplo TestFlight o
distribucion empresarial/ad hoc). Esos pasos requieren cuenta, firma y
dispositivos registrados segun corresponda. No se publica ni distribuye
ninguna app desde este paquete.

INTERACCIONES
-------------

- La invitacion se carga desde archivos incluidos en la app. La vista no tiene
  barra de direcciones ni carga paginas web al iniciar.
- Google Maps solo se solicita al tocar el boton de ubicacion.
- WhatsApp solo se solicita al confirmar asistencia. El invitado revisa y
  envia el mensaje desde WhatsApp.
- Se limita la apertura externa a los destinos existentes del proyecto.
- La musica comienza mediante la accion de abrir y puede estar sujeta a las
  restricciones de audio de iOS.

No se ha compilado ni probado esta app en un iPhone fisico en este entorno.
