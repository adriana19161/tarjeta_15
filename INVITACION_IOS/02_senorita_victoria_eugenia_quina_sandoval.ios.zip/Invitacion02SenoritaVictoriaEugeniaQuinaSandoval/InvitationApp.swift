import SwiftUI
import UIKit
import WebKit

@main
struct InvitationApp: App {
    var body: some Scene {
        WindowGroup {
            InvitationView()
                .ignoresSafeArea()
                .preferredColorScheme(.light)
        }
    }
}

private struct InvitationView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let contentController = WKUserContentController()
        contentController.add(WeakScriptMessageHandler(delegate: context.coordinator), name: "openExternal")
        contentController.add(WeakScriptMessageHandler(delegate: context.coordinator), name: "saveImage")
        contentController.addUserScript(WKUserScript(
            source: """
            window.IS_NATIVE_INVITATION_APP = true;
            const nativeOpen = window.webkit.messageHandlers.openExternal;
            const nativeSave = window.webkit.messageHandlers.saveImage;
            let lastTrustedClick = 0;
            let saveRequestedUntil = 0;
            window.addEventListener('click', function (event) {
                if (!event.isTrusted || !(event.target instanceof Element)) return;
                lastTrustedClick = Date.now();
                if (event.target.closest('#downloadPassBtn')) saveRequestedUntil = Date.now() + 30000;
            }, true);
            window.open = function (url) {
                if (Date.now() - lastTrustedClick > 1200) return null;
                nativeOpen.postMessage(String(url));
                return null;
            };
            document.addEventListener('click', function (event) {
                if (!(event.target instanceof Element)) return;
                const link = event.target.closest('a[download]');
                if (Date.now() > saveRequestedUntil || !link
                    || !link.href.startsWith('data:image/png;base64,')) return;
                event.preventDefault();
                saveRequestedUntil = 0;
                nativeSave.postMessage(link.href.slice('data:image/png;base64,'.length));
            }, true);
            """,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        ))

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 205.0 / 255.0, green: 232.0 / 255.0, blue: 175.0 / 255.0, alpha: 1)
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = true
        webView.scrollView.alwaysBounceHorizontal = false

        if let invitationDirectory = Bundle.main.resourceURL?.appendingPathComponent("Invitation", isDirectory: true) {
            let entry = invitationDirectory.appendingPathComponent("index.html")
            webView.loadFileURL(entry, allowingReadAccessTo: invitationDirectory)
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        private let allowedHosts: Set<String> = ["maps.app.goo.gl", "api.whatsapp.com"]

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let value = message.body as? String else { return }
            if message.name == "openExternal", let url = URL(string: value) {
                openExternal(url)
            } else if message.name == "saveImage",
                      let data = Data(base64Encoded: value),
                      let image = UIImage(data: data) {
                presentShareSheet(with: image)
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            if isLocalInvitationURL(url) {
                decisionHandler(.allow)
                return
            }

            if navigationAction.navigationType == .linkActivated {
                openExternal(url)
            }
            decisionHandler(.cancel)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            guard navigationAction.navigationType == .linkActivated,
                  let url = navigationAction.request.url else { return nil }
            openExternal(url)
            return nil
        }

        private func isLocalInvitationURL(_ url: URL) -> Bool {
            guard url.isFileURL,
                  let root = Bundle.main.resourceURL?.appendingPathComponent("Invitation", isDirectory: true) else { return false }
            let rootPath = root.standardizedFileURL.path
            let directoryPrefix = rootPath.hasSuffix("/") ? rootPath : rootPath + "/"
            let candidatePath = url.standardizedFileURL.path
            return candidatePath == rootPath || candidatePath.hasPrefix(directoryPrefix)
        }

        private func openExternal(_ url: URL) {
            guard url.scheme?.lowercased() == "https",
                  let host = url.host?.lowercased(),
                  allowedHosts.contains(host) else { return }
            UIApplication.shared.open(url)
        }

        private func presentShareSheet(with image: UIImage) {
            guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState == .foregroundActive }),
                  let rootViewController = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }

            let activityController = UIActivityViewController(
                activityItems: [image],
                applicationActivities: nil
            )
            if let popover = activityController.popoverPresentationController {
                popover.sourceView = rootViewController.view
                popover.sourceRect = CGRect(
                    x: rootViewController.view.bounds.midX,
                    y: rootViewController.view.bounds.midY,
                    width: 0,
                    height: 0
                )
            }
            rootViewController.present(activityController, animated: true)
        }
    }
}

private final class WeakScriptMessageHandler: NSObject, WKScriptMessageHandler {
    weak var delegate: WKScriptMessageHandler?

    init(delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
