INVITACION PERSONAL
===================

Este paquete contiene una sola invitacion personalizada y los recursos
necesarios para mostrarla. No reenvies este ZIP junto con paquetes de
otras personas ni compartas la carpeta que los contiene.

Extrae el ZIP y abre index.html. En iPhone, la vista previa de Archivos
puede restringir JavaScript, musica o recursos locales. Para una
experiencia interactiva fiable en Safari se requiere servir el paquete
desde HTTPS; este paquete no esta publicado en Internet.

Los botones de ubicacion y confirmacion conservan sus destinos actuales.
WhatsApp prepara el mensaje, que el invitado debe revisar y enviar.
